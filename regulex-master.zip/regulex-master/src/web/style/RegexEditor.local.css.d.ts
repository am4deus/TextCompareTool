declare const styles: {
  readonly 'base-font-size': string;
  readonly editorCt: string;
  readonly slash: string;
  readonly endSlash: string;
  readonly sourceEditor: string;
  readonly flagsInputCt: string;
  readonly flagsInput: string;
};
export = styles;
