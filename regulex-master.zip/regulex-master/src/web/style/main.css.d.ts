declare const styles: {
  readonly blockCt: string;
  readonly errorIcon: string;
  readonly show: string;
  readonly btnsCt: string;
  readonly diagramCt: string;
  readonly errorBox: string;
  readonly highlight: string;
  readonly normal: string;
  readonly siteLink: string;
  readonly foBtn: string;
  readonly twitterJex: string;
  readonly githubJex: string;
  readonly githubCorner: string;
  readonly octoArm: string;
  readonly octocatWave: string;
};
export = styles;
