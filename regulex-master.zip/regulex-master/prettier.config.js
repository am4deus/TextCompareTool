module.exports = {
  printWidth: 120,
  trailingComma: 'none',
  tabWidth: 2,
  semi: true,
  bracketSpacing: false,
  arrowParens: 'avoid',
  singleQuote: true
};
